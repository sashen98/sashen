
import React, { useState, useEffect, useRef } from 'react';
import { Menu, Send, Bot, User, Loader2, Sparkles, AlertCircle, Database, Copy, Check, Terminal, ExternalLink, Code } from 'lucide-react';
import Sidebar from './components/Sidebar';
import { ChatSession, Message } from './types';
import { supabase } from './lib/supabase';
import { streamAIResponse } from './services/geminiService';

const SQL_SETUP_SCRIPT = `-- 1. Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. Create chats table
CREATE TABLE public.chats (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Create messages table
CREATE TABLE public.messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  chat_id UUID REFERENCES public.chats(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('user', 'model')),
  content TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. Enable RLS and add public policies
ALTER TABLE public.chats ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public all" ON public.chats FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public all" ON public.messages FOR ALL USING (true) WITH CHECK (true);`;

const App: React.FC = () => {
  const [chats, setChats] = useState<ChatSession[]>([]);
  const [currentChatId, setCurrentChatId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [dbError, setDbError] = useState<string | null>(null);
  const [isTableMissing, setIsTableMissing] = useState(false);
  const [copied, setCopied] = useState(false);
  const [viewMode, setViewMode] = useState<'chat' | 'sql'>('chat');
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchChats();
  }, []);

  useEffect(() => {
    if (currentChatId && viewMode === 'chat') {
      fetchMessages(currentChatId);
    } else if (!currentChatId) {
      setMessages([]);
    }
  }, [currentChatId, viewMode]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const fetchChats = async () => {
    setDbError(null);
    setIsTableMissing(false);
    try {
      const { data, error } = await supabase
        .from('chats')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) {
        if (error.code === 'PGRST116' || error.message.includes('public.chats')) {
          setIsTableMissing(true);
        } else {
          setDbError(error.message);
        }
        return;
      }
      if (data) setChats(data);
    } catch (err) {
      setDbError('Failed to connect to Supabase. Check your configuration.');
    }
  };

  const fetchMessages = async (chatId: string) => {
    const { data, error } = await supabase
      .from('messages')
      .select('*')
      .eq('chat_id', chatId)
      .order('created_at', { ascending: true });

    if (error) console.error('Error fetching messages:', error.message);
    if (data) setMessages(data);
  };

  const createNewChat = async () => {
    const { data, error } = await supabase
      .from('chats')
      .insert([{ title: 'New Conversation' }])
      .select()
      .single();

    if (data) {
      setChats([data, ...chats]);
      setCurrentChatId(data.id);
      setIsSidebarOpen(false);
      setViewMode('chat');
    }
    if (error) setDbError(error.message);
  };

  const deleteChat = async (id: string) => {
    const { error } = await supabase.from('chats').delete().eq('id', id);
    if (!error) {
      setChats(chats.filter(c => c.id !== id));
      if (currentChatId === id) setCurrentChatId(null);
    }
  };

  const copySql = (text: string = SQL_SETUP_SCRIPT) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    if (viewMode === 'sql') {
      // Specialized SQL Assistant logic
      const prompt = `Act as a Supabase PostgreSQL expert. Provide the SQL script for: ${input}`;
      setIsLoading(true);
      const userContent = input;
      setInput('');
      
      const placeholderId = 'sql-' + Date.now();
      setMessages(prev => [...prev, 
        { id: 'user-'+placeholderId, chat_id: 'sql', role: 'user', content: userContent, created_at: new Date().toISOString() },
        { id: placeholderId, chat_id: 'sql', role: 'model', content: '', created_at: new Date().toISOString() }
      ]);

      try {
        let currentResponse = "";
        await streamAIResponse(prompt, [], (chunk) => {
          currentResponse += chunk;
          setMessages(prev => prev.map(m => m.id === placeholderId ? { ...m, content: currentResponse } : m));
        });
      } catch (err) { console.error(err); }
      finally { setIsLoading(false); return; }
    }

    // Standard Chat logic
    let chatId = currentChatId;
    if (!chatId) {
      const { data } = await supabase
        .from('chats')
        .insert([{ title: input.slice(0, 30) + (input.length > 30 ? '...' : '') }])
        .select()
        .single();
      if (data) {
        chatId = data.id;
        setChats([data, ...chats]);
        setCurrentChatId(chatId);
      } else return;
    }

    const userContent = input;
    setInput('');
    setIsLoading(true);

    const { data: savedUserMsg } = await supabase
      .from('messages')
      .insert([{ chat_id: chatId, role: 'user', content: userContent }])
      .select()
      .single();

    if (savedUserMsg) setMessages(prev => [...prev, savedUserMsg]);

    try {
      let currentResponse = "";
      const placeholderId = 'streaming-' + Date.now();
      setMessages(prev => [...prev, { id: placeholderId, chat_id: chatId!, role: 'model', content: '', created_at: new Date().toISOString() }]);

      const fullText = await streamAIResponse(userContent, [], (chunk) => {
        currentResponse += chunk;
        setMessages(prev => prev.map(m => m.id === placeholderId ? { ...m, content: currentResponse } : m));
      });

      const { data: savedAiMsg } = await supabase
        .from('messages')
        .insert([{ chat_id: chatId, role: 'model', content: fullText }])
        .select()
        .single();

      if (savedAiMsg) setMessages(prev => prev.map(m => m.id === placeholderId ? savedAiMsg : m));
    } catch (error) { console.error(error); }
    finally { setIsLoading(false); }
  };

  if (isTableMissing) {
    return (
      <div className="min-h-screen bg-slate-900 text-white flex items-center justify-center p-6">
        <div className="max-w-3xl w-full">
          <div className="flex items-center gap-3 mb-8">
            <div className="p-3 bg-indigo-500/20 text-indigo-400 rounded-xl">
              <Database size={32} />
            </div>
            <div>
              <h1 className="text-3xl font-bold">SQL Setup Required</h1>
              <p className="text-slate-400 text-lg">Initialize your Supabase database to start chatting.</p>
            </div>
          </div>

          <div className="bg-slate-800 rounded-2xl border border-slate-700 overflow-hidden shadow-2xl">
            <div className="p-6 border-b border-slate-700">
              <ol className="space-y-4">
                <li className="flex gap-4">
                  <span className="flex-shrink-0 w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center font-bold">1</span>
                  <p className="pt-1">Open your <a href={`https://supabase.com/dashboard/project/njxqjkyxbwrblfxjaeju/sql/new`} target="_blank" className="text-indigo-400 hover:underline flex items-center gap-1 inline-flex">Supabase SQL Editor <ExternalLink size={14} /></a></p>
                </li>
                <li className="flex gap-4">
                  <span className="flex-shrink-0 w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center font-bold">2</span>
                  <p className="pt-1">Paste the script below and click <span className="font-bold text-white bg-indigo-500 px-2 py-0.5 rounded text-sm uppercase">Run</span>.</p>
                </li>
              </ol>
            </div>

            <div className="relative group">
              <div className="absolute top-4 right-4 z-10 flex gap-2">
                <button 
                  onClick={() => copySql()}
                  className="flex items-center gap-2 px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg text-xs transition-colors border border-slate-600"
                >
                  {copied ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
                  {copied ? 'Copied!' : 'Copy SQL'}
                </button>
              </div>
              <div className="bg-slate-950 p-6 font-mono text-sm overflow-x-auto max-h-[350px] custom-scrollbar text-indigo-300 border-y border-slate-700">
                <pre>{SQL_SETUP_SCRIPT}</pre>
              </div>
            </div>

            <div className="p-6 bg-slate-800/50 flex flex-col sm:flex-row gap-4 justify-between items-center">
              <div className="flex items-center gap-2 text-slate-400 text-xs italic">
                <AlertCircle size={14} className="text-amber-500" />
                This will create 'chats' and 'messages' tables.
              </div>
              <button 
                onClick={fetchChats}
                className="w-full sm:w-auto px-8 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl transition-all shadow-lg hover:shadow-indigo-500/30 transform hover:-translate-y-0.5"
              >
                I've run the script, Connect Now
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-50 text-gray-900">
      <Sidebar
        chats={chats}
        currentChatId={currentChatId}
        viewMode={viewMode}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        onNewChat={createNewChat}
        onSelectChat={(id) => {
          setCurrentChatId(id);
          setIsSidebarOpen(false);
          setViewMode('chat');
        }}
        onDeleteChat={deleteChat}
        setViewMode={setViewMode}
      />

      <div className="flex-1 flex flex-col h-full overflow-hidden relative">
        {dbError && (
          <div className="bg-red-50 border-b border-red-100 p-3 flex items-center justify-center gap-3 text-red-700 text-sm">
            <AlertCircle size={18} />
            <span>{dbError}</span>
            <button onClick={fetchChats} className="underline font-bold hover:text-red-800 transition-colors">Retry</button>
          </div>
        )}

        <header className="h-16 flex items-center justify-between px-4 bg-white border-b border-gray-200 lg:px-8 shrink-0">
          <div className="flex items-center gap-4">
            <button onClick={() => setIsSidebarOpen(true)} className="lg:hidden p-2 text-gray-500 hover:bg-gray-100 rounded-lg">
              <Menu size={24} />
            </button>
            <div className="flex flex-col">
              <h2 className="text-lg font-bold text-gray-800 truncate max-w-xs md:max-w-md">
                {viewMode === 'sql' ? 'SQL Lab Assistant' : (currentChatId ? (chats.find(c => c.id === currentChatId)?.title || 'Chat') : 'New Chat')}
              </h2>
              <span className="text-[10px] text-gray-400 uppercase font-bold tracking-wider -mt-1">
                {viewMode === 'sql' ? 'PostgreSQL Expert' : 'Gemini 3 Pro'}
              </span>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
             <div className="hidden md:flex items-center gap-1.5 px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-[10px] font-bold uppercase border border-indigo-100">
              <Database size={12} />
              Connected
            </div>
            <div className="px-3 py-1 bg-green-50 text-green-700 text-xs font-medium rounded-full flex items-center gap-1.5">
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
              Live
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 space-y-6 custom-scrollbar lg:px-12 lg:py-8 bg-white/30 backdrop-blur-sm">
          {viewMode === 'sql' && messages.filter(m => m.chat_id === 'sql').length === 0 && (
            <div className="max-w-2xl mx-auto space-y-8 mt-12">
              <div className="text-center">
                <div className="inline-flex p-4 bg-indigo-100 text-indigo-600 rounded-2xl mb-4 shadow-sm">
                  <Terminal size={48} />
                </div>
                <h1 className="text-3xl font-extrabold text-gray-900 tracking-tight">SQL Lab</h1>
                <p className="text-gray-500 mt-2">Generate optimized Supabase PostgreSQL scripts using AI.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  { title: "Authentication", desc: "Create user profiles on signup", icon: <User size={18}/> },
                  { title: "Row Level Security", desc: "Protect your data tables", icon: <AlertCircle size={18}/> },
                  { title: "Relationships", desc: "Join tables with foreign keys", icon: <Database size={18}/> },
                  { title: "Edge Logic", desc: "Postgres triggers and functions", icon: <Code size={18}/> }
                ].map((feature, i) => (
                  <div key={i} className="p-5 bg-white border border-gray-100 rounded-2xl shadow-sm hover:border-indigo-200 transition-all cursor-default">
                    <div className="w-10 h-10 bg-indigo-50 text-indigo-500 rounded-xl flex items-center justify-center mb-4">
                      {feature.icon}
                    </div>
                    <h3 className="font-bold text-gray-800">{feature.title}</h3>
                    <p className="text-sm text-gray-500 mt-1">{feature.desc}</p>
                  </div>
                ))}
              </div>

              <div className="p-6 bg-slate-900 rounded-2xl text-white shadow-xl relative overflow-hidden group">
                <div className="absolute right-0 top-0 w-32 h-32 bg-indigo-500/10 blur-3xl rounded-full"></div>
                <h4 className="font-bold text-indigo-400 text-sm uppercase tracking-widest mb-4">Quick Tip</h4>
                <p className="text-sm text-slate-300 leading-relaxed italic">
                  "Try asking for a policy that allows users to only read their own rows, or a trigger that updates a 'updated_at' timestamp."
                </p>
              </div>
            </div>
          )}

          {viewMode === 'chat' && messages.length === 0 && !isLoading && (
            <div className="h-full flex flex-col items-center justify-center text-center max-w-md mx-auto">
              <div className="w-16 h-16 bg-indigo-100 text-indigo-600 rounded-2xl flex items-center justify-center mb-6 shadow-sm border border-indigo-200">
                <Bot size={32} />
              </div>
              <h1 className="text-3xl font-extrabold text-gray-900 mb-2">Sashen123 AI</h1>
              <p className="text-gray-500 mb-8 leading-relaxed">Start a conversation with the world's most capable AI. All your history is saved in your Supabase project.</p>
              <div className="w-full space-y-3">
                {["Explain quantum computing in simple terms", "Write a creative short story about a neon cat", "Help me build a React app with Supabase"].map(s => (
                  <button key={s} onClick={() => setInput(s)} className="w-full p-4 text-sm text-gray-700 bg-white border border-gray-200 rounded-xl hover:border-indigo-300 hover:bg-indigo-50 transition-all text-left shadow-sm flex items-center justify-between group">
                    {s}
                    <Terminal size={14} className="opacity-0 group-hover:opacity-100 transition-opacity text-indigo-400" />
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="max-w-4xl mx-auto space-y-6">
            {(viewMode === 'sql' ? messages.filter(m => m.chat_id === 'sql') : messages).map((msg) => (
              <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2 duration-300`}>
                <div className={`flex gap-3 max-w-[95%] md:max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                  <div className={`flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center ${msg.role === 'user' ? 'bg-indigo-600 text-white shadow-lg' : 'bg-white border border-gray-200 text-indigo-500 shadow-sm'}`}>
                    {msg.role === 'user' ? <User size={20} /> : (viewMode === 'sql' ? <Terminal size={20} /> : <Bot size={20} />)}
                  </div>
                  <div className={`px-5 py-4 rounded-2xl shadow-sm border ${msg.role === 'user' ? 'bg-indigo-600 border-indigo-500 text-white' : 'bg-white border-gray-100 text-gray-800'}`}>
                    <div className="whitespace-pre-wrap leading-relaxed text-sm md:text-base prose prose-sm max-w-none">
                      {msg.content || (msg.id.toString().includes('streaming') || msg.id.toString().includes('sql') ? <Loader2 className="animate-spin text-indigo-400" size={20} /> : null)}
                    </div>
                    {msg.role === 'model' && viewMode === 'sql' && msg.content && (
                       <button 
                        onClick={() => copySql(msg.content)}
                        className="mt-4 flex items-center gap-2 px-3 py-1.5 bg-gray-50 hover:bg-indigo-50 text-indigo-600 rounded-lg text-xs font-bold transition-all border border-indigo-100"
                      >
                        <Copy size={12} />
                        {copied ? 'Copied' : 'Copy Script'}
                      </button>
                    )}
                    <div className={`text-[10px] mt-2 opacity-50 font-medium ${msg.role === 'user' ? 'text-right' : 'text-left'}`}>
                      {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Input area */}
        <div className="p-4 bg-white/80 backdrop-blur-md border-t border-gray-200 lg:px-12 lg:pb-8 shrink-0">
          <form onSubmit={handleSendMessage} className="max-w-4xl mx-auto relative">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={viewMode === 'sql' ? "Describe your database needs (e.g. 'Create a table for products')..." : "Ask Sashen123 anything..."}
              className="w-full bg-gray-50 border border-gray-200 text-gray-900 text-sm rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 block p-4 pr-16 transition-all shadow-inner placeholder:text-gray-400"
              disabled={isLoading}
            />
            <button
              type="submit"
              disabled={!input.trim() || isLoading}
              className={`absolute right-2 top-2 bottom-2 px-5 rounded-xl transition-all flex items-center gap-2 font-bold ${
                input.trim() && !isLoading ? 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-xl scale-100 active:scale-95' : 'bg-gray-100 text-gray-300 scale-100'
              }`}
            >
              <span className="hidden sm:inline text-xs uppercase tracking-widest">{isLoading ? 'Thinking' : 'Send'}</span>
              {isLoading ? <Loader2 className="animate-spin" size={18} /> : <Send size={18} />}
            </button>
          </form>
          <div className="max-w-4xl mx-auto flex justify-between items-center mt-3 px-2">
            <div className="flex gap-4">
               <span className="text-[10px] text-gray-400 flex items-center gap-1">
                <Code size={10} /> Markdown Supported
              </span>
              <span className="text-[10px] text-gray-400 flex items-center gap-1">
                <Database size={10} /> Supabase Sync On
              </span>
            </div>
            <p className="text-[10px] text-gray-400">
              Powered by Sashen123
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
