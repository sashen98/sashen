
import { createClient } from '@supabase/supabase-js';

// Configuration provided by user
const supabaseUrl = 'https://njxqjkyxbwrblfxjaeju.supabase.co';
const supabaseKey = 'sb_publishable_UBfzS71UlJz_mn9vtiatKg_sVqy4zdU';

/**
 * SQL SCHEMA SETUP (Run this in Supabase SQL Editor):
 * 
 * -- 1. Enable UUID extension
 * CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
 * 
 * -- 2. Create chats table
 * CREATE TABLE public.chats (
 *   id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
 *   title TEXT NOT NULL,
 *   created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
 * );
 * 
 * -- 3. Create messages table
 * CREATE TABLE public.messages (
 *   id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
 *   chat_id UUID REFERENCES public.chats(id) ON DELETE CASCADE,
 *   role TEXT NOT NULL CHECK (role IN ('user', 'model')),
 *   content TEXT NOT NULL,
 *   created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
 * );
 * 
 * -- 4. Enable RLS and add public policies (for development)
 * ALTER TABLE public.chats ENABLE ROW LEVEL SECURITY;
 * ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
 * 
 * CREATE POLICY "Allow public all" ON public.chats FOR ALL USING (true) WITH CHECK (true);
 * CREATE POLICY "Allow public all" ON public.messages FOR ALL USING (true) WITH CHECK (true);
 */

export const supabase = createClient(supabaseUrl, supabaseKey);
