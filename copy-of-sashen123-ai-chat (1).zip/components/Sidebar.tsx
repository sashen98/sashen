
import React from 'react';
import { Plus, MessageSquare, Trash2, X, Bot, Terminal, LayoutDashboard } from 'lucide-react';
import { ChatSession } from '../types';

interface SidebarProps {
  chats: ChatSession[];
  currentChatId: string | null;
  viewMode: 'chat' | 'sql';
  isOpen: boolean;
  onClose: () => void;
  onNewChat: () => void;
  onSelectChat: (id: string) => void;
  onDeleteChat: (id: string) => void;
  setViewMode: (mode: 'chat' | 'sql') => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  chats,
  currentChatId,
  viewMode,
  isOpen,
  onClose,
  onNewChat,
  onSelectChat,
  onDeleteChat,
  setViewMode,
}) => {
  return (
    <div className={`fixed inset-y-0 left-0 z-50 w-72 bg-white border-r border-gray-200 transform transition-transform duration-300 ease-in-out lg:relative lg:translate-x-0 ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
      <div className="flex flex-col h-full">
        {/* Logo Section */}
        <div className="p-4 border-b border-gray-100 flex items-center justify-between">
          <div className="flex items-center gap-2 font-bold text-indigo-600">
            <Bot size={24} />
            <span className="text-xl tracking-tight">Sashen123</span>
          </div>
          <button onClick={onClose} className="lg:hidden p-2 hover:bg-gray-100 rounded-lg">
            <X size={20} />
          </button>
        </div>

        {/* View Switcher */}
        <div className="p-2 flex gap-1 bg-gray-50 m-4 rounded-xl border border-gray-100">
          <button 
            onClick={() => setViewMode('chat')}
            className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-sm font-medium transition-all ${viewMode === 'chat' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
          >
            <LayoutDashboard size={16} />
            Chat
          </button>
          <button 
            onClick={() => setViewMode('sql')}
            className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-sm font-medium transition-all ${viewMode === 'sql' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
          >
            <Terminal size={16} />
            SQL Lab
          </button>
        </div>

        {viewMode === 'chat' ? (
          <>
            <div className="px-4 pb-4">
              <button
                onClick={onNewChat}
                className="w-full flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-3 px-4 rounded-xl transition-colors shadow-sm"
              >
                <Plus size={20} />
                New Chat
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-2 custom-scrollbar">
              <div className="space-y-1">
                {chats.length === 0 ? (
                  <div className="p-4 text-center text-sm text-gray-400">No chats yet</div>
                ) : (
                  chats.map((chat) => (
                    <div
                      key={chat.id}
                      className={`group flex items-center justify-between p-3 rounded-lg cursor-pointer transition-all ${
                        currentChatId === chat.id 
                          ? 'bg-indigo-50 text-indigo-700' 
                          : 'hover:bg-gray-100 text-gray-700'
                      }`}
                      onClick={() => onSelectChat(chat.id)}
                    >
                      <div className="flex items-center gap-3 overflow-hidden">
                        <MessageSquare size={18} className={currentChatId === chat.id ? 'text-indigo-600' : 'text-gray-400'} />
                        <span className="truncate text-sm font-medium">{chat.title}</span>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteChat(chat.id);
                        }}
                        className="opacity-0 group-hover:opacity-100 p-1 hover:text-red-600 transition-opacity"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 px-4 py-2 space-y-4 overflow-y-auto custom-scrollbar">
            <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider px-2">Common Scripts</h3>
            <div className="space-y-1">
              {['Reset Database', 'Add Auth Support', 'Setup Storage', 'RLS Templates'].map((item) => (
                <button key={item} className="w-full text-left p-3 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-lg transition-colors flex items-center gap-2">
                  <Terminal size={14} className="text-indigo-400" />
                  {item}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="p-4 border-t border-gray-100">
          <div className="text-[10px] text-gray-400 text-center uppercase tracking-widest font-bold">
            Sashen123 v1.0
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
