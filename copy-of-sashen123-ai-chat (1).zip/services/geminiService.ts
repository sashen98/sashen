
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const getAI = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
};

export const streamAIResponse = async (
  prompt: string, 
  history: { role: 'user' | 'model', parts: { text: string }[] }[],
  onChunk: (text: string) => void
) => {
  const ai = getAI();
  const chat = ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction: "You are a helpful, professional AI assistant named SashenBot. Provide concise and accurate information.",
    },
  });

  try {
    const result = await chat.sendMessageStream({ message: prompt });
    let fullText = "";
    for await (const chunk of result) {
      const text = (chunk as GenerateContentResponse).text || "";
      fullText += text;
      onChunk(text);
    }
    return fullText;
  } catch (error) {
    console.error("Gemini Error:", error);
    throw error;
  }
};
