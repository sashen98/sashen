
export interface Message {
  id: string;
  chat_id: string;
  role: 'user' | 'model';
  content: string;
  created_at: string;
}

export interface ChatSession {
  id: string;
  title: string;
  created_at: string;
}

export interface AppState {
  currentChatId: string | null;
  chats: ChatSession[];
  messages: Message[];
  isLoading: boolean;
  isSidebarOpen: boolean;
}
